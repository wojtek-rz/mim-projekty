#include <unistd.h>
#include <stdio.h>

#define SCHEDULE_N 10

const int period = 100000;

int main() {
    int schedule[SCHEDULE_N];
    for (int i = 0; i < SCHEDULE_N; i++){
        schedule[i] = 1;
    }

    for (int i = 0; i < SCHEDULE_N; i++){
        fprintf(stderr, "line %d\n", i);
        fflush(stderr);

        usleep(schedule[i] * period);
    }
    return 0;
}