#include <unistd.h>
#include <stdio.h>

#define N 10

const int period = 100000; // 100 milliseconds

int main() {

    for (int i = 0; i < N; i++){
        if (i % 2){
            fprintf(stderr, "err line %d\n", i/2);
            fflush(stderr);
        } else {
            fprintf(stdout, "out line %d\n", i/2);
            fflush(stdout);
        }

        usleep(period);
    }
    return 0;
}