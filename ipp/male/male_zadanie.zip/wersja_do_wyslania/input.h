#ifndef IPP_MALE_INPUT_H
#define IPP_MALE_INPUT_H

#include "array.h"
#include "bitvectors.h"
#include "types.h"

extern int read_input(Labyrinth labyrinth);

#endif //IPP_MALE_INPUT_H
