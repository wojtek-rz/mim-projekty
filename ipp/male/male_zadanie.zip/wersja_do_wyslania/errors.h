#ifndef IPP_MALE_ERRORS_H
#define IPP_MALE_ERRORS_H

extern void memory_allocation_error();

extern void wrong_input_error(int line);

#endif //IPP_MALE_ERRORS_H
